import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class KeyStatic here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class KeyStatic extends Actor
{
    public KeyStatic(){
        GreenfootImage image = getImage();
        image.scale(image.getWidth()-1100, image.getHeight()-1100);  //scaling
        setImage(image);
    }

    /**
     * Act - do whatever the KeyStatic wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setRotation(90);
        getWorld().showText("Key Collected!", 670, 55);  //show this text at the previous key's location
        if(isTouching(Door.class) && isTouching(MainCharacter2.class)){
            ((MyWorld) getWorld()).playMusic();  //if the game has been won, tell the world play music
        }
    }    
}
