import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Elevator2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Elevator2 extends Actor
{
    int ElevatorCounter=0;  //check Elevator.class code, it's the same
    public Elevator2(){
        GreenfootImage img = new GreenfootImage( 85, 100);
        img.drawRect(0, 0,100,100); 
        img.setColor(Color.YELLOW);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Elevator2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkDOWN();
        checkUP();
    }    

    private void checkDOWN(){
        if(getY()<=272){
            if(isTouching(MainCharacter2.class) && Greenfoot.isKeyDown("down")){
                setLocation(getX(), getY()+3);  //move down if below the third floor, touching your character and the down arrow is being pressed
            }
        }
    }

    private void checkUP(){
        if(isTouching(MainCharacter2.class) && Greenfoot.isKeyDown("up")){
            ElevatorCounter++;
            if(ElevatorCounter>=100){
                setLocation(getX(), getY()-3);
            }
        }
        if(isTouching(MainCharacter3.class)){
            getWorld().addObject(new Elevator3(), 100, 50);
        }
        if(((MyWorld) getWorld()).sublife){
            getWorld().addObject(new Elevator(), 100, 500);  //if a life has been lost, add the first elevator in its position (because the first character is being added in, too)
        }
        if(isTouching(MainCharacter3.class) || ((MyWorld) getWorld()).sublife){ 
            getWorld().removeObject(this);
        }
    }    

}
