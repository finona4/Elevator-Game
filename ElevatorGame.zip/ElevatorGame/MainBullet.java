import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainBullet extends Actor
{
    public MainBullet(int direction){
        GreenfootImage img = new GreenfootImage( 8, 2);
        img.drawRect(0, 0,7,1); 
        img.setColor(Color.BLUE);
        img.fill();
        setImage(img);
        setRotation(direction);  //make the bullet a blue rectangle
    }

    /**
     * Act - do whatever the MainBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(5);  //start moving once created (in the direction chosen by the hero)
        moveLeft();
    }    

    private void moveLeft(){
        if(isAtEdge() || isTouching(Enemy.class)|| isTouching(Enemy2.class)|| isTouching(Enemy3.class) || isTouching(Enemy4.class) || isTouching(Enemy5.class)||isTouching(Enemy6.class)){
            getWorld().removeObject(this);  //if at the edge or touching any enemies, remove yourself
        }
    }
}    
