import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy4 extends Actor
{
    int counter=0;  //look at Enemy.class for comments
    int walkcounter=0;
    int spacebar=0;
    boolean bullet=false;
    int counterBullet=0;
    int bulletdirection=0;
    boolean notHit=true;
    boolean incScore=true;
    /**
     * Act - do whatever the Enemy4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        moveNow();
        checkBullet();
        checkHit();
    }    

    private void moveNow(){
        counter++;
        walkcounter++;
        if(notHit==true){
            if(counter<200){
                setLocation(getX()-1, getY());
                bulletdirection=180;
                setImage("EnemyWalk1flip.png");
                if(walkcounter>=20){
                    setImage("EnemyWalk2flip.png");
                    if(walkcounter>=40){
                        walkcounter=0;
                    }
                }
            }
            if(counter>=200){
                setLocation(getX()+1, getY());
                setImage("EnemyWalk1.png");
                bulletdirection=0;
                if(walkcounter>=20){
                    setImage("EnemyWalk2.png");
                    if(walkcounter>=40){
                        walkcounter=0;
                    }
                }
                if(counter>=400){
                    counter=Greenfoot.getRandomNumber(100);
                }

            }
        }
    }

    private void checkBullet(){
        counterBullet++;
        if(notHit==true){
            if (counterBullet>=50 && (!bullet)){
                EnemyBullet theBullet = new EnemyBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());
                counterBullet=0;
                spacebar++;
                bullet=true;
            }
            else{
                bullet=false;
                spacebar=0;
            }
            if(spacebar>=1){
                counterBullet++;
                if (counterBullet>=50){
                    EnemyBullet theBullet = new EnemyBullet(bulletdirection);
                    getWorld().addObject(theBullet, getX(), getY());
                    counterBullet=0;
                }
            }
        }
    }

    private void checkHit(){
        if(isTouching(MainBullet.class)){
            notHit=false;
            setLocation(getX(), getY());
            setImage("EnemyDeath.png");
            if(incScore==true){
                ((MyWorld) getWorld()).updateScore();
                incScore=false;
            }
        }
    }
}    
