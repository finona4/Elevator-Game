import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    private GreenfootSound music = new GreenfootSound("elevatormusicedit3.mp3"); //music is variable to allow smooth playing
    private GreenfootSound music2 = new GreenfootSound("rickroll.mp3");
    private GreenfootSound music3 = new GreenfootSound("bossmusic.mp3");
    private ScoreBoard score;
    private ScoreBoard2 points;
    private ScoreBoard3 lives;
    private Door rick;
    private ScoreBoard4 boss;
    boolean sublife=false;
    boolean musicPlaying=false;
    boolean startBoss=false;
    boolean endBoss=false;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
        score=new ScoreBoard();
        points=new ScoreBoard2();
        lives=new ScoreBoard3();
        boss=new ScoreBoard4();
        rick=new Door();
        addObject(score, 100, 50);
        addObject(points, 100, 5);
        addObject(lives, 200, 5);
        addObject(boss, 0, 0);
        addObject(rick, 750, 290);
    }

    public void started()
    {
        music.playLoop();  //to make the background music loop over once the game starts
    }

    public void act()
    {
        if(endBoss==true){
            music3.stop();
            music.play();
        }
        if(musicPlaying==true && startBoss==false){
            music.stop();
            music2.play();  //if the game has been won and the victory music should play, stop the background music and start the victory music
        }
        if(startBoss==true){
            music.stop();
            music3.play();
        }

    }

    public void prepare(){
        setPaintOrder(Starting.class, ScoreBoard.class, ScoreBoard2.class, ScoreBoard3.class, MainCharacter.class, GameOver.class, Boss.class,MainCharacter2.class, KeyStatic.class,MainCharacter3.class, Floor1.class, Floor2.class, Floor3.class, MainBullet.class, EnemyBullet.class, Enemy.class, Enemy2.class, Enemy3.class, Enemy4.class, Enemy5.class, Enemy6.class);
        addObject(new Elevator(), 100, 500);
        addObject(new Floor1(), 400, 575);
        addObject(new Floor2(), 400, 350);
        addObject(new Floor3(), 400, 125);
        addObject(new MainCharacter(), 100, 515);
        addObject(new Enemy(), 380, 510);
        addObject(new Enemy2(), 670, 510);
        //addObject(new Enemy3(), 380, 285);
        addObject(new Enemy4(), 670, 285);
        addObject(new Enemy5(), 380, 60);
        //addObject(new Enemy6(), 670, 60);
        addObject(new Key(), 700, 60);
        addObject(new Door(), 750, 290);
        addObject(new Starting(), getWidth()/2, getHeight()/2);  //add the starting screen
    }

    public void update(){
        score.subHealth();  //for the scoreboard that tracks health
    }

    public void updateScore(){
        points.addToScore();  //for the scoreboard that tracks score
    }

    public void updateLives(){
        sublife=true;
        startBoss=false; //needed variable so it could be accessed by actors
        lives.subLives();  //for the scoreboard that tracks lives
    }

    public void playMusic(){
        if(startBoss==false){
            musicPlaying=true;  //if the game has been won, victory music should be playing
            rick.rickRoll();  
        }//if the game has been won, allow the Door to do its thing
    }

    public void playBoss(){
        startBoss=true;
        musicPlaying=false;
        boss.playBoss();
    }

    public void endBoss(){
        endBoss=true;
        startBoss=false;
        boss.endBoss();
    }
}
