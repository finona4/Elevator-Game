import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Elevator3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Elevator3 extends Actor
{
    int ElevatorCounter=0;  //check Elevator2.class code, it's the same
    public Elevator3(){
        GreenfootImage img = new GreenfootImage( 85, 100);
        img.drawRect(0, 0,100,100); 
        img.setColor(Color.YELLOW);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Elevator3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkDOWN();
    }    

    private void checkDOWN(){
        if(isTouching(MainCharacter3.class) && Greenfoot.isKeyDown("down")){
            ElevatorCounter++;
            if(ElevatorCounter>=100){
                setLocation(getX(), getY()+3);
            }
        }
        if(isTouching(MainCharacter2.class)){
            getWorld().addObject(new Elevator2(), getX(), getY());
        }
        if(((MyWorld) getWorld()).sublife){
            getWorld().addObject(new Elevator(), 100, 500);
        }
        if(((MyWorld) getWorld()).sublife){
            getWorld().addObject(new Elevator(), 100, 500); 
        }
        if (isTouching(MainCharacter2.class) || ((MyWorld) getWorld()).sublife){
            getWorld().removeObject(this);
        }
    }   
}    
