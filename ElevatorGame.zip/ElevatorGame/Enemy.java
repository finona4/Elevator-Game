
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    int counter=0;
    int walkcounter=0;
    int spacebar=0;
    boolean bullet=false;
    int counterBullet=0;
    int bulletdirection=0;
    boolean notHit=true;  //Has the enemy been hit by the hero's bullet?
    boolean incScore=true; //Can the score still be increased?
    /**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        moveNow();
        checkBullet();
        checkHit();
    }    

    private void moveNow(){
        counter++;
        walkcounter++;
        if(notHit==true){
            if(counter<200){
                setLocation(getX()+1, getY());  //if the counter is less than 200, keep moving right
                bulletdirection=0;  //the bullets will fire right
                setImage("EnemyWalk1.png");
                if(walkcounter>=20){
                    setImage("EnemyWalk2.png");  //switch to the second walking sprite for a walking animation
                    if(walkcounter>=40){
                        walkcounter=0;  //switch back to the first walking sprite
                    }
                }
            }
            if(counter>=200){
                setLocation(getX()-1, getY());  //once the counter gets greater than 200, start going left
                setImage("EnemyWalk1flip.png");  //now the sprite is flipped
                bulletdirection=180;  //bullets will fire left
                if(walkcounter>=20){
                    setImage("EnemyWalk2flip.png");
                    if(walkcounter>=40){
                        walkcounter=0;
                    }
                }
                if(counter>=400){
                    counter=Greenfoot.getRandomNumber(100);  //once the counter becomes greater than 400, the walking patterns will become random
                }
            }
        }
    }

    private void checkBullet(){
        counterBullet++;
        if(notHit==true){  //if not dead, keep shooting bullets
            if (counterBullet>=50 && (!bullet)){
                EnemyBullet theBullet = new EnemyBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());  //add a bullet at regular intervals, in the direction being faced
                counterBullet=0;
                spacebar++;
                bullet=true;
            }
            else{
                bullet=false;
                spacebar=0;
            }
            if(spacebar>=1){
                counterBullet++;
                if (counterBullet>=50){
                    EnemyBullet theBullet = new EnemyBullet(bulletdirection);
                    getWorld().addObject(theBullet, getX(), getY());
                    counterBullet=0;  //this whole thing just regulates the intervals
                }
            }
        }
    }

    private void checkHit(){
        if(isTouching(MainBullet.class)){
            notHit=false;  //now you've been hit
            setLocation(getX(), getY());  //stay in the same spot
            setImage("EnemyDeath.png");  //switch to the fallen sprite
            if(incScore==true){
            ((MyWorld) getWorld()).updateScore();  //if the score can still be increased, update it
            incScore=false;  //now that you're already dead, getting hit won't give the hero points
        }
        }
    }
}
