import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss extends Actor
{
    int hitCounter=0;
    public Boss(){
        GreenfootImage image = getImage();
        image.scale(image.getWidth()+50, image.getHeight()+50);  //scaling
        setImage(image);
        getWorld().addObject(new FireCircle(), getX(), getY());
    }

    /**
     * Act - do whatever the BOss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {

        checkHit();
    }    

    private void checkHit(){
        if(isTouching(MainBullet.class)){
            hitCounter++;
        }
        if(hitCounter>=10){
            ((MyWorld) getWorld()).endBoss();
            getWorld().removeObject(this);
        }
    }
}
