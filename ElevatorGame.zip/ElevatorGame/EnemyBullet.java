import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyBullet extends Actor
{
    public EnemyBullet(int direction){
        GreenfootImage img = new GreenfootImage( 8, 2);
        img.drawRect(0, 0,7,1); 
        img.setColor(Color.RED);
        img.fill();
        setImage(img);
        setRotation(direction);  //make the bullets red rectangles
    }

    /**
     * Act - do whatever the EnemyBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(5);  //start moving (in the direction chosen by the Enemy)
        moveLeft();
    }    

    private void moveLeft(){
        if(isAtEdge()){
            getWorld().removeObject(this);
        }
    }
}
