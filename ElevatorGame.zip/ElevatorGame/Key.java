import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Key here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Key extends Actor
{
    GifImage myGif = new GifImage("key1..gif");
    public Key(){
        int scalePercent=50;
        for (GreenfootImage image : myGif.getImages()){
            int wide = image.getWidth()*scalePercent/1050;
            int high = image.getHeight()*scalePercent/1050;
            image.scale(wide, high);  //code for making a gif work
        }
    }

    /**
     * Act - do whatever the Key wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setImage(myGif.getCurrentImage());
        if(isTouching(MainCharacter3.class)){
            Greenfoot.playSound("keysound.mp3");
            ((MyWorld) getWorld()).playBoss();
            ((MyWorld) getWorld()).updateScore();  //if the hero collects the key, give him a point
            getWorld().addObject(new KeyStatic(), 752, 290);  //add a static key at the door
            getWorld().removeObject(this);
        }
    }
}
