import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FireCircle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FireCircle extends Boss
{
    /**
     * Act - do whatever the FireCircle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        turn(10);
    }    
}
