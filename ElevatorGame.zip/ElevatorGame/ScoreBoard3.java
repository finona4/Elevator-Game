import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreBoard3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreBoard3 extends Actor
{
    private int lives;  //look at ScoreBoard.class for comments
    private Font myFont = new Font("Comic Sans MS", false, true, 24);
    public ScoreBoard3(){
        lives = 1;
        GreenfootImage img = new GreenfootImage(150,60);
        img.setFont( myFont );
        img.drawString("Lives: " + lives, 20, 50);
        setImage(img);
    }

    /**
     * Act - do whatever the ScoreBoard3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    

    public void subLives() 
    {
        lives--;
        Greenfoot.playSound("aww.mp3");  //play the sad sound if a life has been lost
        GreenfootImage img = getImage();
        img.clear();
        setImage(img);
        getWorld().addObject(new GameOver(), getWorld().getWidth()/2, getWorld().getHeight()/2);  //add the game over screen
        if(lives>1) {
            img.drawString("Lives: " + lives, 20,25); 
        } else {
            img.drawString("Game Over", 20,25);
        }        
    }    
}
