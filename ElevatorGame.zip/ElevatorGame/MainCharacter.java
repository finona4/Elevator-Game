import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainCharacter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainCharacter extends Actor
{
    private boolean flip=false;  //Should the character look like it's moving left?
    int  acceleration = 1;
    int vSpeed = 4;
    int speed = 5;
    int jumpStrength = 15;
    int ElevatorCounter=0;
    boolean elevator=false;
    int spacebar=0;
    boolean bullet=false;
    int counter=0;
    int bulletdirection=0;
    int walkcounter=0;
    int health=10;
    boolean isDead=false;  //Have you been hit yet?
    /**
     * Act - do whatever the MainCharacter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(elevator==false){
            checkFall();
            checkKeys();  //if not in the elevator, you can move and fall
        }
        if (!Greenfoot.isKeyDown("right") && !Greenfoot.isKeyDown("left") && !Greenfoot.isKeyDown("up") && flip==false && isDead==false){
            setImage("MainStanding.png");  //if no key is being pressed and you're not dead, stand idly
        }
        if (!Greenfoot.isKeyDown("right") && !Greenfoot.isKeyDown("left") && !Greenfoot.isKeyDown("up") && flip==true && isDead==false){
            setImage("MainStandingflip.png"); //if no key is being pressed and you should face the left, and you're not dead, stand idly
        }
        checkHit();
        checkElevator();
        checkBullet(); 
    }

    public boolean onGround()
    {
        Actor under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Floor1.class);
        return under != null;
    }

    public void Fall()
    {
        setLocation (getX(), getY() + vSpeed);
        vSpeed = vSpeed += acceleration;
    }

    public void checkFall()
    {          
        if (onGround())
        {
            vSpeed = 0;}
        else {
            Fall();
        }
    }

    public void checkKeys()
    {
        if(isDead==false){  //if you're not dead, you can move and jump
            if (Greenfoot.isKeyDown("left"))
            {
                moveLeft();
            }
            if(Greenfoot.isKeyDown("right"))
            {
                moveRight(); 
            }
            if(Greenfoot.isKeyDown("up") && onGround())
            {
                jump(); 
            }
        }
    }

    public void jump()
    {
        vSpeed = -jumpStrength;
        Fall();
        if(elevator==false){
            setImage("MainJump.png");  //if you're not in the elevator and you're jumping, look like it
        }
    }

    public void moveLeft()
    {
        walkcounter++;
        bulletdirection=180;
        setLocation(getX() - speed, getY());  
        setImage("MainWalk1flip.png");
        if(walkcounter>=20){
            setImage("MainWalk2flip.png");
            if(walkcounter>=40){
                walkcounter=0;  //for walking animations
            }
        }
        flip=true;  //the sprites should be flipped
    }

    public void moveRight()
    {
        walkcounter++;
        bulletdirection=0;
        setLocation(getX() + speed, getY()); 
        setRotation(0);
        setImage("MainWalk1.png");
        if(walkcounter>=20){
            setImage("MainWalk2.png");
            if(walkcounter>=40){
                walkcounter=0;
            }
        }
        flip=false;
    }

    private void checkBullet(){
        if(Greenfoot.isKeyDown("space") && isDead==false){
            if(!bullet){
                MainBullet theBullet = new MainBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());
                bullet=true;
                spacebar++;
            }
        }
        else{
            bullet=false;
            spacebar=0;
        }
        if(spacebar>=1){
            counter++;
            if (counter>=50){
                MainBullet theBullet = new MainBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());
                counter=0;  //all of this is obvious
            }
        }
    }

    public void checkHit(){
        if(isTouching(EnemyBullet.class) && isDead==false){  //if you've been hit but you're not already dead
            removeTouching(EnemyBullet.class);  //remove the bullet that hit you
            ((MyWorld) getWorld()).update();  //tell the world to take away health
            health--;
        }
        if(((MyWorld) getWorld()).sublife){  //if a life has been lost
            isDead=true;  //now you're dead, so you can't move anymore
            setLocation(getX(), getY());
            setImage("MainDeath.png");  //set image to the fallen sprite
        }
    }

    private void checkElevator(){
        if(isTouching(Elevator.class) && Greenfoot.isKeyDown("up")){
            setImage("MainStanding.png");
            elevator=true;  //if in the elevator and the up arrow is pressed, it's true that you're in the elevator so you can't fall now
        }
        if(isTouching(Elevator.class) && Greenfoot.isKeyDown("up") && elevator){
            ElevatorCounter++;
            if(ElevatorCounter>=100){
                setLocation(getX(), getY()-3);  //start moving up with the elevator after 100 iterations
            }
        }
        else{
            elevator=false;  //otherwise you're still not in the elevator
        }
        if(getY()<=300){
            elevator=false;
            getWorld().addObject(new MainCharacter2(),getX(), getY());
            getWorld().removeObject(this);  //if you're now on the 2nd floor, add the second character in your place and remove yourself
        }
    }
}
