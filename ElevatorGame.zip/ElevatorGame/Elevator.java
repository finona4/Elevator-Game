import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Elevator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Elevator extends Actor
{
    int ElevatorCounter=0;  //will count how long the up arrow has been held so the elevator doesn't go up immediately
    public Elevator(){
        GreenfootImage img = new GreenfootImage( 85, 100);
        img.drawRect(0, 0,100,100); 
        img.setColor(Color.YELLOW);
        img.fill();
        setImage(img);  //making the elevator a yellow square
    }

    /**
     * Act - do whatever the Elevator wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkUP();
    }    

    private void checkUP(){
        if(isTouching(MainCharacter.class) && Greenfoot.isKeyDown("up")){
            ElevatorCounter++;
            if(ElevatorCounter>=100){
                setLocation(getX(), getY()-3);  //if the up arrow has been held for more 100 thingies, start moving up
            }
        }
        if(isTouching(MainCharacter2.class)){
            getWorld().addObject(new Elevator2(), 100, 275);
            getWorld().removeObject(this); //if the character has been switched, add its elevator and remove yourself
        }
    }
}
