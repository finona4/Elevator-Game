import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreBoard extends Actor
{
    private int health;
    private Font myFont = new Font("Comic Sans MS", false, true, 24);
    public ScoreBoard(){
        health = 10;        
        GreenfootImage img = new GreenfootImage(150,30);
        img.setFont( myFont );
        img.drawString("Health: " + health, 5,25);
        setImage(img);  //make the scoreboard this text
    }

    /**
     * Act - do whatever the ScoreBoard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    

    public void subHealth() 
    {
        health--;
        GreenfootImage img = getImage();
        img.clear();
        setImage(img);
        if(health >1) {
            img.drawString("Health: " + health, 5,25);  //if the hero has more than one health, display this
        } else {
            ((MyWorld) getWorld()).updateLives();
            health=10;  //if the hero has 0 health, tell the world to subtract a life and reset the health bar
        }        
    }    

}
