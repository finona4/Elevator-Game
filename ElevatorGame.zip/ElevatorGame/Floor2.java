import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Floor2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor2 extends Actor
{
    public Floor2(){
        GreenfootImage img = new GreenfootImage( 800, 50);
        img.drawRect(0, 0,800,50); 
        img.setColor(Color.RED);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Floor2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
