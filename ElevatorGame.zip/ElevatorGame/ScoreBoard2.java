import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreBoard2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreBoard2 extends Actor
{
    private int score;  //look at ScoreBoard.class for comments
    private Font myFont = new Font("Comic Sans MS", false, true, 24);
    public ScoreBoard2(){
        score = 0;
        GreenfootImage img2 = new GreenfootImage(150,60);
        img2.setFont( myFont );
        img2.drawString("Score: " + score, 5, 50);
        setImage(img2);
    }

    /**
     * Act - do whatever the ScoreBoard2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }   

    public void addToScore(){
        score++;
        GreenfootImage img2 = getImage();
        img2.clear();
        setImage(img2);
        if(score <30) {
            img2.drawString("Score: " + score, 5,50); 
        } else {
            img2.drawString("You Win!", 5,50);
        }   
    }
}