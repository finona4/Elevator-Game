import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainCharacter2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainCharacter2 extends Actor
{
    private boolean flip=false;  //look at MainCharacter.class for code
    int  acceleration = 1;
    int vSpeed = 4;
    int speed = 5;
    int jumpStrength = 15;
    int ElevatorCounter=0;
    boolean elevator=false;
    boolean goingtosecond=false;
    int spacebar=0;
    boolean bullet=false;
    int counter=0;
    int bulletdirection=0;
    int walkcounter=0;
    boolean won=false;  //Have you won yet?
    /**
     * Act - do whatever the MainCharacter2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(elevator==false){
            checkFall();
            checkKeys();
        }
        if (!Greenfoot.isKeyDown("right") && !Greenfoot.isKeyDown("left") && !Greenfoot.isKeyDown("up") && flip==false && won==false){
            setImage("MainStanding.png");
        }
        if (!Greenfoot.isKeyDown("right") && !Greenfoot.isKeyDown("left") && !Greenfoot.isKeyDown("up") && flip==true && won==false){
            setImage("MainStandingflip.png");
        }
        if(isTouching(KeyStatic.class) && isTouching(Door.class) && ((MyWorld) getWorld()).endBoss){
            won=true;
            setImage("MainVictory.png");  //if you're at the unlocked door, you've won (so you can't move are take damage anymore)
        }
        checkHit();
        checkElevator();
        checkBullet();
    }    

    public boolean onGround()
    {
        Actor under = getOneObjectAtOffset(0, getImage().getHeight()/2 + 2, Floor2.class);
        return under != null;
    }

    public void Fall()
    {
        setLocation (getX(), getY() + vSpeed);
        vSpeed = vSpeed += acceleration;
    }

    public void checkFall()
    {     
        if(goingtosecond==false){
            if (onGround())
            {
                vSpeed = 0;}
            else {
                Fall();
            }
        }
    }

    public void checkKeys()
    {
        if(won==false){  //if you haven't won yet, you can do these things
        if (Greenfoot.isKeyDown("left"))
        {
            moveLeft();
        }
        if(Greenfoot.isKeyDown("right"))
        {
            moveRight(); 
        }
        if(Greenfoot.isKeyDown("up") && onGround())
        {
            jump(); 
        }
    }
    }

    private void checkBullet(){
        if(Greenfoot.isKeyDown("space") && won==false){  //if you haven't won yet, you can still shoot
            if(!bullet){
                MainBullet theBullet = new MainBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());
                bullet=true;
                spacebar++;
            }
        }
        else{
            bullet=false;
            spacebar=0;
        }
        if(spacebar>=1){
            counter++;
            if (counter>=50){
                MainBullet theBullet = new MainBullet(bulletdirection);
                getWorld().addObject(theBullet, getX(), getY());
                counter=0;
            }
        }
    }

    public void checkHit(){
        if(isTouching(EnemyBullet.class) && won==false){  //if you haven't won yet, you can still take damage
            removeTouching(EnemyBullet.class);
            ((MyWorld) getWorld()).update();
        }
        if(((MyWorld) getWorld()).sublife){
            getWorld().addObject(new MainCharacter(), 100, 515);  //if a life has been lost, add the first character back on the first floor
        }
    }

    private void checkElevator(){
        if(isTouching(Elevator2.class) && Greenfoot.isKeyDown("up")){
            setImage("MainStanding.png");
            elevator=true;
        }
        if(isTouching(Elevator2.class) && Greenfoot.isKeyDown("up") && elevator){
            ElevatorCounter++;
            if(ElevatorCounter>=100){
                setLocation(getX(), getY()-3);
            }
        }
        else{
            elevator=false;
        }
        if(getY()<=286 && isTouching(Elevator2.class) && Greenfoot.isKeyDown("down")){
            goingtosecond=true;
            setLocation(getX(), getY()+3);
        }

        else{
            goingtosecond=false;
        }
        if(getY()<=100){
            elevator=false;
            getWorld().addObject(new MainCharacter3(),getX(), getY());
        }
        if(getY()<=100 || ((MyWorld) getWorld()).sublife){
            getWorld().removeObject(this);
        }
    }

    public void jump()
    {
        vSpeed = -jumpStrength;
        Fall();
        if(elevator==false){
            setImage("MainJump.png");
        }
    }

    public void moveLeft()
    {
        walkcounter++;
        bulletdirection=180;
        setLocation(getX() - speed, getY());  
        setImage("MainWalk1flip.png");
        if(walkcounter>=20){
            setImage("MainWalk2flip.png");
            if(walkcounter>=40){
                walkcounter=0;
            }
        }
        flip=true;
    }

    public void moveRight()
    {
        walkcounter++;
        bulletdirection=0;
        setLocation(getX() + speed, getY()); 
        setRotation(0);
        setImage("MainWalk1.png");
        if(walkcounter>=20){
            setImage("MainWalk2.png");
            if(walkcounter>=40){
                walkcounter=0;
            }
        }
        flip=false;
    }
}
