import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Floor3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Floor3 extends Actor
{
    public Floor3(){
        GreenfootImage img = new GreenfootImage( 800, 50);
        img.drawRect(0, 0,800,50); 
        img.setColor(Color.RED);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the Floor3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
