import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends Key
{
    public Door(){
        GreenfootImage image = getImage();
        image.scale(image.getWidth()-1000, image.getHeight()-1000);  //scaling
        setImage(image);
    }

    /**
     * Act - do whatever the Door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {

    }    

    public void rickRoll(){
        getWorld().showText("You Win!", 400, 300);  //if the game has been won, show this text
    }
}